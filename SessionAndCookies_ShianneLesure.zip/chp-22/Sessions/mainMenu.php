<div class="w3-bar w3-theme-d5">
    <a href = "setSession.php" class="w3-bar-item w3-button">Set</a>
    <a href = "getSession.php" class="w3-bar-item w3-button">Get</a>

    <div class="w3-dropdown-hover">
        <button class="w3-button">Unset</button>
        <div class="w3-dropdown-content w3-bar-block w3-card-4">
            <a href="unsetID.php" class="w3-bar-item w3-button">ID</a>
            <a href="unsetFirstName.php" class="w3-bar-item w3-button">First Name</a>
            <a href="unsetLastName.php" class="w3-bar-item w3-button">Last Name</a>
        </div>
    </div>

<a href="destroySession.php" class="w3-bar-item w3-button">Destory</a>
</div>