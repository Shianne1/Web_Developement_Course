<div class="w3-bar w3-theme-d5">
    <a href="setCookie.php" class="w3-bar-item w3-button">Set cookies</a>
    <a href="getCookie.php" class="w3-bar-item w3-button">Get cookies</a>
    <a href="deleteCookie.php" class="w3-bar-item w3-button">Delete cookies</a>
</div>